document.getElementById("onemore").addEventListener("click", beHappy, false);

function beHappy () {
	document.write("<p>행운은 마음의 준비가 있는 사람에게만 미소를 짓는다.</p><p> -파스퇴르</p>");
}