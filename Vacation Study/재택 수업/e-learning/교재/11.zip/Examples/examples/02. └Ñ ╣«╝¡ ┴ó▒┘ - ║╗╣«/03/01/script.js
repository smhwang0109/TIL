var textBlock = document.getElementsByTagName("p");

textBlock[2].innerHTML = "이것은 세 번째 단락입니다.";