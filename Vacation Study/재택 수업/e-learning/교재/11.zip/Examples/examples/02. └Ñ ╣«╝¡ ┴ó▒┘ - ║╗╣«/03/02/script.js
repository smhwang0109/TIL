console("이것은 세 번째 단락입니다.")

function console (outputString) {
	document.getElementById("console").innerHTML = outputString;
}