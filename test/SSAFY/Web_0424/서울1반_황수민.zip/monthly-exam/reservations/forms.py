# Q2-1
from django import forms                 # django.forms 불러오기
from .models import Reservation          # Reservation 모델 불러오기

class ReservationForm(forms.ModelForm):  # 모델 폼으로 생성
    class Meta:                          # 기본 데이터 작성을 위한 class
        model = Reservation              # Reservation 모델 사용
        fields = '__all__'               # 모든 필드 값 받도록 정의