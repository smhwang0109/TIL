from django.db import models

# Create your models here.
class Reservation(models.Model):
    date = models.DateField()
    personnel = models.IntegerField()
    location = models.CharField(max_length=20)

# Q3-1
class Reply(models.Model):
    comment = models.TextField()                                            # comment 칼럼 TextField로 정의
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE)  # reservation 칼럼 ForeignKey 이용해서 Reservation 모델과 1:N 관계 설정 (on_delete=models.CASCADE는 부모 테이블 데이터가 삭제되면 자식데이터도 삭제)