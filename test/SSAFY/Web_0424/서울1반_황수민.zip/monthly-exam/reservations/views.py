# 각 문제를 해결하기 위하여 필요한 import문은 이곳에 작성합니다.
from django.shortcuts import render, redirect                    # redirect 추가
from .models import Reservation                                  # Reservation 모델 불러오기
from .forms import ReservationForm                               # ReservationForm 불러오기

def index(request):
    # Q2-3
    reservations = Reservation.objects.order_by('-date')         # reservations_reservation 테이블의 date 컬럼을 기준으로 내림차순 정렬해서 queryset 가져오기
    context = {
        'reservations': reservations                             # 위에서 가져온 queryset 을 reservations 변수로 넘겨주기
    }
    return render(request, 'reservations/index.html', context)   # index.html 반환

def create(request):
    # Q2-2
    if request.method == 'POST':                                 # POST 방식
        form = ReservationForm(request.POST)                     # ReservationForm에 입력 받은 정보 넣기
        if form.is_valid():                                      # 유효성 검사
            form.save()                                          # 입력 받은 정보 저장
            return redirect('reservations:index')                # /reservations/ 경로로 리다이렉트
    else:                                                        # GET 방식
        form = ReservationForm()                                 # 비어있는 입력 양식 폼 제공
    context = {
        'form': form                                             # GET 방식에서 비어 있는 입력 폼을 받거나 POST 방식에서 유효성 검사 실패 시 오류메시지와 함께 폼 받음
    }
    return render(request, 'reservations/create.html', context)  # create.html 반환